// Main entry point for your iii project

export function hello(name: string): string {
  return `Hello, ${name}!`;
}

console.log(hello("iii"));
