# iii Quickstart (new)

Three workers, three primitives — learn iii in under two minutes.

**What you build:** A counter with an HTTP endpoint, persistent state, real-time
stream updates, and a React dashboard — all wired through the iii engine.

## Architecture

```
┌─────────────┐     ws:49134     ┌───────────┐
│   counter    │◄───────────────►│           │
│   worker     │                 │           │
└─────────────┘                  │    iii    │
┌─────────────┐     ws:49134     │  engine   │
│ state-worker │◄───────────────►│           │
└─────────────┘                  │           │
┌─────────────┐  ws:3112 stream  │           │
│  dashboard   │◄───────────────►│           │
│  (browser)   │                 └───────────┘
└─────────────┘
```

## Prerequisites

- **iii engine** installed ([iii.dev/docs](https://iii.dev/docs))
- **Node.js 18+**

## Quick Start

### 1. Start the engine

```bash
iii -c iii-config.yaml
```

### 2. Start the counter worker

```bash
cd workers/counter
npm install
npm run dev
```

### 3. Try the HTTP endpoint

```bash
# Read the count
curl http://localhost:3111/counter

# Increment
curl -X POST http://localhost:3111/counter/increment

# Or use the iii CLI
iii trigger --function-id='counter::get' --payload='{}'
iii trigger --function-id='counter::increment' --payload='{}'
```

### 4. Start the state worker

Open a new terminal:

```bash
cd workers/state-worker
npm install
npm run dev
```

The state worker reacts to counter changes via a `state` trigger. Check the
engine logs — you'll see `state-worker::on-count-change` fire each time the
counter increments.

### 5. Open the dashboard

Open another terminal:

```bash
cd workers/dashboard
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173). The dashboard:

- Shows the live counter via iii's **Stream** WebSocket (no polling)
- Lists all registered **functions** (live discovery)
- Logs **state changes** as they happen

Click **Increment** in the browser or curl from the terminal — the count updates
everywhere instantly.

## What's happening

| Worker | What it does |
|---|---|
| **counter** | Registers `counter::get` and `counter::increment`. On increment, writes to both `state::set` and `stream::set` so state persists and the dashboard gets a real-time push. |
| **state-worker** | Registers a `state` trigger on `scope: counter, key: count`. Fires `state-worker::on-count-change` whenever the counter state updates. Demonstrates a third worker appearing in live discovery. |
| **dashboard** | A Vite+React app that connects to the engine's Stream WebSocket (port 3112) and REST API (port 3111). No iii Node SDK needed in the browser — just native WebSocket. |

## Key concepts demonstrated

- **Workers** — independent processes that connect to the engine over WebSocket
- **Functions** — `counter::get`, `counter::increment`, `state-worker::health`
- **Triggers** — `http`, `state`
- **Streams** — real-time push to browser clients
- **Discovery** — the dashboard sees all registered functions
- **State** — persistent key-value store with reactive triggers
