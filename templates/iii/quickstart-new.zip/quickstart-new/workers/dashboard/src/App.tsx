import { useEffect, useRef, useState, useCallback } from 'react'

const STREAM_URL = 'ws://localhost:3112'
const API_URL = 'http://localhost:3111'

type StreamEvent = {
  type: string
  streamName: string
  groupId: string
  id?: string
  event: { type: string; data: unknown }
}

type FunctionInfo = {
  function_id: string
  description?: string
}

type StateLog = {
  ts: number
  key: string
  value: unknown
}

function useStreamCounter() {
  const [count, setCount] = useState<number | null>(null)
  const wsRef = useRef<WebSocket | null>(null)

  useEffect(() => {
    const ws = new WebSocket(STREAM_URL)
    wsRef.current = ws

    ws.addEventListener('open', () => {
      ws.send(
        JSON.stringify({
          type: 'join',
          data: {
            subscriptionId: 'counter-sub',
            streamName: 'counter',
            groupId: 'default',
          },
        }),
      )
    })

    ws.addEventListener('message', (e) => {
      try {
        const msg: StreamEvent = JSON.parse(e.data)
        const data = msg.event?.data as Record<string, unknown> | undefined
        if (data && typeof data.count === 'number') {
          setCount(data.count)
        }
      } catch {
        /* ignore non-json frames */
      }
    })

    ws.addEventListener('close', () => {
      wsRef.current = null
    })

    return () => {
      ws.close()
    }
  }, [])

  return count
}

function useFunctions() {
  const [functions, setFunctions] = useState<FunctionInfo[]>([])

  const refresh = useCallback(async () => {
    try {
      const res = await fetch(`${API_URL}/iii/functions`)
      if (res.ok) {
        const body = await res.json()
        setFunctions(body.functions ?? body ?? [])
      }
    } catch {
      /* engine not reachable yet */
    }
  }, [])

  useEffect(() => {
    refresh()
    const id = setInterval(refresh, 3000)
    return () => clearInterval(id)
  }, [refresh])

  return functions
}

function useStateLogs() {
  const [logs, setLogs] = useState<StateLog[]>([])
  const wsRef = useRef<WebSocket | null>(null)

  useEffect(() => {
    const ws = new WebSocket(STREAM_URL)
    wsRef.current = ws

    ws.addEventListener('open', () => {
      ws.send(
        JSON.stringify({
          type: 'join',
          data: {
            subscriptionId: 'state-sub',
            streamName: 'counter',
            groupId: 'default',
          },
        }),
      )
    })

    ws.addEventListener('message', (e) => {
      try {
        const msg: StreamEvent = JSON.parse(e.data)
        if (msg.event?.type === 'create' || msg.event?.type === 'update') {
          setLogs((prev) => [
            ...prev.slice(-49),
            {
              ts: Date.now(),
              key: msg.id ?? 'count',
              value: msg.event.data,
            },
          ])
        }
      } catch {
        /* ignore */
      }
    })

    ws.addEventListener('close', () => {
      wsRef.current = null
    })

    return () => ws.close()
  }, [])

  return logs
}

async function increment() {
  try {
    await fetch(`${API_URL}/counter/increment`, { method: 'POST' })
  } catch {
    /* engine not reachable */
  }
}

export function App() {
  const count = useStreamCounter()
  const functions = useFunctions()
  const stateLogs = useStateLogs()

  return (
    <div className="container">
      <h1>iii Quickstart</h1>

      <section className="card">
        <h2>Counter</h2>
        <p className="count">{count ?? '—'}</p>
        <button onClick={increment}>Increment</button>
        <p className="hint">
          or: <code>curl -X POST http://localhost:3111/counter/increment</code>
        </p>
      </section>

      <section className="card">
        <h2>Live Discovery</h2>
        {functions.length === 0 ? (
          <p className="muted">No functions registered yet.</p>
        ) : (
          <ul>
            {functions.map((fn) => (
              <li key={fn.function_id}>
                <code>{fn.function_id}</code>
                {fn.description && (
                  <span className="muted"> — {fn.description}</span>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="card">
        <h2>State Change Log</h2>
        {stateLogs.length === 0 ? (
          <p className="muted">
            Waiting for state changes… click Increment above.
          </p>
        ) : (
          <ul className="logs">
            {stateLogs.map((log, i) => (
              <li key={i}>
                <span className="ts">
                  {new Date(log.ts).toLocaleTimeString()}
                </span>{' '}
                <code>{log.key}</code> → {JSON.stringify(log.value)}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}
