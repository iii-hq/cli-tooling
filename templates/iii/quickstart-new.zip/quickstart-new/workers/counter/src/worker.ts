import { registerWorker, Logger, TriggerAction } from 'iii-sdk'

const iii = registerWorker(process.env.III_URL ?? 'ws://localhost:49134', {
  workerName: 'counter',
})
const logger = new Logger()

let count = 0

iii.registerFunction('counter::increment', async () => {
  count++

  await iii.trigger({
    function_id: 'state::set',
    payload: { scope: 'counter', key: 'count', value: { count } },
    action: TriggerAction.Void(),
  })

  await iii.trigger({
    function_id: 'stream::set',
    payload: {
      stream_name: 'counter',
      group_id: 'default',
      item_id: 'count',
      data: { count },
    },
  })

  logger.info('Incremented', { count })
  return { count }
})

iii.registerTrigger({
  type: 'http',
  function_id: 'counter::increment',
  config: { api_path: '/counter/increment', http_method: 'POST' },
})

iii.registerFunction('counter::get', async () => {
  const stored = await iii.trigger<{ count: number } | null>({
    function_id: 'state::get',
    payload: { scope: 'counter', key: 'count' },
  })

  const current = stored?.count ?? count
  return { count: current }
})

iii.registerTrigger({
  type: 'http',
  function_id: 'counter::get',
  config: { api_path: '/counter', http_method: 'GET' },
})

logger.info('Counter worker started')
