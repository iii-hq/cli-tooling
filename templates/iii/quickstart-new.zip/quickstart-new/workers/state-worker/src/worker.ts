import { registerWorker, Logger } from 'iii-sdk'

const iii = registerWorker(process.env.III_URL ?? 'ws://localhost:49134', {
  workerName: 'state-worker',
})
const logger = new Logger()

iii.registerFunction('state-worker::health', async () => {
  return { status: 'ok', worker: 'state-worker', timestamp: Date.now() }
})

iii.registerTrigger({
  type: 'http',
  function_id: 'state-worker::health',
  config: { api_path: '/state-worker/health', http_method: 'GET' },
})

// React to counter state changes
iii.registerFunction('state-worker::on-count-change', async (event) => {
  logger.info('Counter state changed', {
    key: event.key,
    new_value: event.new_value,
  })
  return { handled: true }
})

iii.registerTrigger({
  type: 'state',
  function_id: 'state-worker::on-count-change',
  config: { scope: 'counter', key: 'count' },
})

logger.info('State worker started')
